#define NUMBER 42

extern int number;

extern int foo (void);
extern int bar (int);
