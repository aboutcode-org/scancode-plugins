package main

const (
	// TestImageManifestDigest is the Docker manifest digest of "fixtures/image.manifest.json"
	TestImageManifestDigest = "sha256:20bf21ed457b390829cdbeec8795a7bea1626991fda603e0d01b4e7f60427e55"
)
