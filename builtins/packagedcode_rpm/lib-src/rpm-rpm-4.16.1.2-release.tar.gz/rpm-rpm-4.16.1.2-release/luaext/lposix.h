#ifndef LPOSIX_H
#define LPOSIX_H

int luaopen_posix (lua_State *L);

#endif
