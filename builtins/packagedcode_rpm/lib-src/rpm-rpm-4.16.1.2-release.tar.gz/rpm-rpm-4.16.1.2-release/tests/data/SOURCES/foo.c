#include "foobar.h"

int
foo ()
{
  return number;
}
