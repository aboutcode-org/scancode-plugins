#include "foobar.h"

int
main ()
{
  int res;
  res = foo ();
  res = bar (res);
  return res + number - NUMBER;
}
