#include "foobar.h"

int number = NUMBER;

int
bar (int n)
{
  return n - NUMBER;
}
