#! /bin/sh
if ./main; then
    exit 1
fi
